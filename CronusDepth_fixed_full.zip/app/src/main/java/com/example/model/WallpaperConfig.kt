package com.example.model

enum class WallpaperSourceType {
    PRESET,
    CUSTOM_PHOTO
}

enum class SensorMode {
    FUSION_GYRO,
    ACCELEROMETER_ECO
}

enum class ParticleType {
    STARDUST,
    FIREFLIES,
    NEON_CYBER,
    SNOW_CRYSTAL
}

enum class ColorPreset {
    ORIGINAL,
    VIBRANT_AMOLED,
    CYBER_NEON,
    DEEP_CONTRAST,
    WARM_GOLDEN
}

data class WallpaperPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val drawableResName: String,
    val defaultDepth: Float = 2.8f,
    val defaultParticleType: ParticleType = ParticleType.STARDUST,
    val recommendedColorPreset: ColorPreset = ColorPreset.ORIGINAL
)

data class WallpaperConfig(
    val sourceType: WallpaperSourceType = WallpaperSourceType.PRESET,
    val presetId: String = "cyber_nebula",
    val customImagePath: String? = null,
    val depthIntensity: Float = 2.6f,       // Parallax pixel translation multiplier
    val perspectiveTilt: Float = 16.0f,     // 3D camera rotation angle (degrees)
    val sensorMode: SensorMode = SensorMode.FUSION_GYRO,
    val sensorSensitivity: Float = 1.3f,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val holographicSheen: Boolean = true,
    val sheenIntensity: Float = 0.45f,
    val particlesEnabled: Boolean = true,
    val particleType: ParticleType = ParticleType.STARDUST,
    val particleCount: Int = 28,
    val ambientDrift: Boolean = true,       // Gentle breathing idle motion
    val driftSpeed: Float = 1.0f,
    val colorPreset: ColorPreset = ColorPreset.ORIGINAL,
    val targetFps: Int = 60,                // 30, 60, 90, 120
    val batterySaverAutoThrottle: Boolean = true,
    val dampingSmoothness: Float = 0.14f    // Silky lerp coefficient
)

object BuiltInPresets {
    val presets = listOf(
        WallpaperPreset(
            id = "cyber_nebula",
            name = "Cosmic Nebula",
            subtitle = "Deep stellar clouds & celestial rings",
            drawableResName = "preset_cyber_nebula",
            defaultDepth = 3.2f,
            defaultParticleType = ParticleType.STARDUST,
            recommendedColorPreset = ColorPreset.ORIGINAL
        ),
        WallpaperPreset(
            id = "cyber_city",
            name = "Neo Tokyo 2099",
            subtitle = "Cyberpunk megacity with rainy neon reflections",
            drawableResName = "preset_cyber_city",
            defaultDepth = 2.8f,
            defaultParticleType = ParticleType.NEON_CYBER,
            recommendedColorPreset = ColorPreset.CYBER_NEON
        ),
        WallpaperPreset(
            id = "quantum_void",
            name = "Quantum Matrix",
            subtitle = "Pure AMOLED void with holographic rings",
            drawableResName = "preset_quantum_void",
            defaultDepth = 3.5f,
            defaultParticleType = ParticleType.FIREFLIES,
            recommendedColorPreset = ColorPreset.VIBRANT_AMOLED
        )
    )
}
