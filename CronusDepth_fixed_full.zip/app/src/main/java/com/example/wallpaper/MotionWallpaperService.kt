package com.example.wallpaper

import android.graphics.Bitmap
import android.os.Handler
import android.os.HandlerThread
import android.os.PowerManager
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.example.data.WallpaperRepository
import com.example.engine.MotionSensorTracker
import com.example.engine.Wallpaper3DRenderer
import com.example.model.WallpaperConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

class MotionWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return MotionEngine()
    }

    inner class MotionEngine : Engine(), Choreographer.FrameCallback {

        private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
        private lateinit var repository: WallpaperRepository
        private lateinit var sensorTracker: MotionSensorTracker
        private val renderer = Wallpaper3DRenderer()

        private var activeConfig = WallpaperConfig()
        private var wallpaperBitmap: Bitmap? = null

        private var surfaceWidth = 0f
        private var surfaceHeight = 0f
        private var isVisibleOnScreen = false

        private var choreographer: Choreographer? = null
        private var lastFrameTimeNanos = 0L
        private var lastMotionTimeMs = 0L

        private var prevTiltX = 0f
        private var prevTiltY = 0f

        // Touch tracking
        private var lastTouchX = 0f
        private var lastTouchY = 0f

        private lateinit var powerManager: PowerManager
        private var renderThread: HandlerThread? = null
        private var renderHandler: Handler? = null

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)
            repository = WallpaperRepository.getInstance(applicationContext)
            powerManager = getSystemService(POWER_SERVICE) as PowerManager

            setTouchEventsEnabled(true)

            sensorTracker = MotionSensorTracker(applicationContext) { _, _ ->
                // Sensor motion updated
            }

            // Start dedicated low-overhead render thread
            renderThread = HandlerThread("MotionWallpaperRenderThread").apply { start() }
            renderHandler = Handler(renderThread!!.looper)

            // Listen to repository config updates in real time
            serviceScope.launch {
                repository.configFlow.collect { newConfig ->
                    val sourceChanged = activeConfig.sourceType != newConfig.sourceType ||
                            activeConfig.presetId != newConfig.presetId ||
                            activeConfig.customImagePath != newConfig.customImagePath

                    val depthOrTiltChanged = activeConfig.depthIntensity != newConfig.depthIntensity ||
                            activeConfig.perspectiveTilt != newConfig.perspectiveTilt

                    activeConfig = newConfig

                    // Always reload when source/path changes or bitmap is missing.
                    // Also reload on first surface so custom image is guaranteed to appear.
                    if (sourceChanged || wallpaperBitmap == null || depthOrTiltChanged) {
                        reloadBitmap()
                    }

                    if (isVisibleOnScreen) {
                        sensorTracker.startTracking(activeConfig)
                    }
                }
            }
        }

        private fun reloadBitmap() {
            serviceScope.launch(Dispatchers.IO) {
                val w = surfaceWidth.toInt().coerceAtLeast(1080)
                val h = surfaceHeight.toInt().coerceAtLeast(1920)
                val bmp = repository.loadWallpaperBitmap(activeConfig, w, h)

                renderHandler?.post {
                    // Recycle previous bitmap to free memory (important for large custom photos)
                    val old = wallpaperBitmap
                    wallpaperBitmap = bmp
                    if (old != null && old != bmp && !old.isRecycled) {
                        try { old.recycle() } catch (_: Exception) {}
                    }
                    // Force an immediate frame so the new image appears without waiting for motion
                    if (isVisibleOnScreen) {
                        lastMotionTimeMs = SystemClock.uptimeMillis()
                    }
                }
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder?) {
            super.onSurfaceCreated(holder)
            choreographer = Choreographer.getInstance()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder?, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceWidth = width.toFloat()
            surfaceHeight = height.toFloat()
            // Always reload on size change so custom photo is applied with correct resolution
            // even if the engine was created before the user picked the image.
            reloadBitmap()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            isVisibleOnScreen = visible

            if (visible) {
                sensorTracker.startTracking(activeConfig)
                lastFrameTimeNanos = 0L
                lastMotionTimeMs = SystemClock.uptimeMillis()
                choreographer?.postFrameCallback(this)
            } else {
                // BATTERY OPTIMIZATION: Zero CPU / GPU usage when screen is off or obscured
                sensorTracker.stopTracking()
                choreographer?.removeFrameCallback(this)
            }
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!isVisibleOnScreen) return

            // Compute frame target interval for battery-optimized pacing
            val isPowerSave = activeConfig.batterySaverAutoThrottle && powerManager.isPowerSaveMode
            val targetFps = if (isPowerSave) 30 else activeConfig.targetFps
            val frameIntervalNanos = 1_000_000_000L / targetFps.coerceIn(30, 120)

            val elapsedNanos = frameTimeNanos - lastFrameTimeNanos
            if (elapsedNanos >= frameIntervalNanos || lastFrameTimeNanos == 0L) {
                val deltaTimeSeconds = if (lastFrameTimeNanos == 0L) {
                    1.0f / targetFps
                } else {
                    (elapsedNanos / 1_000_000_000.0f).coerceIn(0.001f, 0.1f)
                }
                lastFrameTimeNanos = frameTimeNanos

                // Update physics
                sensorTracker.updateFrame(deltaTimeSeconds, activeConfig)

                // Stillness check: if phone is still and ambient drift is off, sleep rendering
                val deltaX = abs(sensorTracker.smoothTiltX - prevTiltX)
                val deltaY = abs(sensorTracker.smoothTiltY - prevTiltY)
                val now = SystemClock.uptimeMillis()

                if (deltaX > 0.0008f || deltaY > 0.0008f || activeConfig.ambientDrift || activeConfig.particlesEnabled) {
                    lastMotionTimeMs = now
                }
                prevTiltX = sensorTracker.smoothTiltX
                prevTiltY = sensorTracker.smoothTiltY

                val isStill = !activeConfig.ambientDrift &&
                        !activeConfig.particlesEnabled &&
                        (now - lastMotionTimeMs > 4000L)

                if (!isStill) {
                    drawFrame(deltaTimeSeconds, isPowerSave)
                }
            }

            // Schedule next frame
            if (isVisibleOnScreen) {
                choreographer?.postFrameCallback(this)
            }
        }

        private fun drawFrame(deltaTimeSeconds: Float, isPowerSave: Boolean) {
            val holder = surfaceHolder ?: return
            var canvas: android.graphics.Canvas? = null

            try {
                canvas = holder.lockHardwareCanvas()
                if (canvas != null) {
                    renderer.draw(
                        canvas = canvas,
                        bitmap = wallpaperBitmap,
                        width = surfaceWidth,
                        height = surfaceHeight,
                        tiltX = sensorTracker.smoothTiltX,
                        tiltY = sensorTracker.smoothTiltY,
                        config = activeConfig,
                        deltaTimeSeconds = deltaTimeSeconds,
                        isPowerSaverActive = isPowerSave
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        override fun onTouchEvent(event: MotionEvent?) {
            super.onTouchEvent(event)
            if (event == null) return

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.x
                    lastTouchY = event.y
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.x - lastTouchX) / surfaceWidth.coerceAtLeast(1f)
                    val dy = (event.y - lastTouchY) / surfaceHeight.coerceAtLeast(1f)
                    sensorTracker.injectTouchDelta(-dx * 1.8f, dy * 1.8f)
                    lastTouchX = event.x
                    lastTouchY = event.y
                    lastMotionTimeMs = SystemClock.uptimeMillis()
                }
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            isVisibleOnScreen = false
            sensorTracker.stopTracking()
            choreographer?.removeFrameCallback(this)
            renderThread?.quitSafely()
            serviceScope.cancel()
        }
    }
}
