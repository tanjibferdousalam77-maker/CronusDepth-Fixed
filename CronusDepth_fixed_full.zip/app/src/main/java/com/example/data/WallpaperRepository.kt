package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.model.BuiltInPresets
import com.example.model.ColorPreset
import com.example.model.ParticleType
import com.example.model.SensorMode
import com.example.model.WallpaperConfig
import com.example.model.WallpaperSourceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class WallpaperRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _configFlow = MutableStateFlow(loadConfig())
    val configFlow: StateFlow<WallpaperConfig> = _configFlow.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _configFlow.value = loadConfig()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun loadConfig(): WallpaperConfig {
        val sourceTypeStr = prefs.getString(KEY_SOURCE_TYPE, WallpaperSourceType.PRESET.name)
        val sourceType = try {
            WallpaperSourceType.valueOf(sourceTypeStr ?: WallpaperSourceType.PRESET.name)
        } catch (_: Exception) {
            WallpaperSourceType.PRESET
        }

        val sensorModeStr = prefs.getString(KEY_SENSOR_MODE, SensorMode.FUSION_GYRO.name)
        val sensorMode = try {
            SensorMode.valueOf(sensorModeStr ?: SensorMode.FUSION_GYRO.name)
        } catch (_: Exception) {
            SensorMode.FUSION_GYRO
        }

        val particleTypeStr = prefs.getString(KEY_PARTICLE_TYPE, ParticleType.STARDUST.name)
        val particleType = try {
            ParticleType.valueOf(particleTypeStr ?: ParticleType.STARDUST.name)
        } catch (_: Exception) {
            ParticleType.STARDUST
        }

        val colorPresetStr = prefs.getString(KEY_COLOR_PRESET, ColorPreset.ORIGINAL.name)
        val colorPreset = try {
            ColorPreset.valueOf(colorPresetStr ?: ColorPreset.ORIGINAL.name)
        } catch (_: Exception) {
            ColorPreset.ORIGINAL
        }

        return WallpaperConfig(
            sourceType = sourceType,
            presetId = prefs.getString(KEY_PRESET_ID, "cyber_nebula") ?: "cyber_nebula",
            customImagePath = prefs.getString(KEY_CUSTOM_IMAGE_PATH, null),
            depthIntensity = prefs.getFloat(KEY_DEPTH_INTENSITY, 2.6f),
            perspectiveTilt = prefs.getFloat(KEY_PERSPECTIVE_TILT, 16.0f),
            sensorMode = sensorMode,
            sensorSensitivity = prefs.getFloat(KEY_SENSOR_SENSITIVITY, 1.3f),
            invertX = prefs.getBoolean(KEY_INVERT_X, false),
            invertY = prefs.getBoolean(KEY_INVERT_Y, false),
            holographicSheen = prefs.getBoolean(KEY_HOLOGRAPHIC_SHEEN, true),
            sheenIntensity = prefs.getFloat(KEY_SHEEN_INTENSITY, 0.45f),
            particlesEnabled = prefs.getBoolean(KEY_PARTICLES_ENABLED, true),
            particleType = particleType,
            particleCount = prefs.getInt(KEY_PARTICLE_COUNT, 28),
            ambientDrift = prefs.getBoolean(KEY_AMBIENT_DRIFT, true),
            driftSpeed = prefs.getFloat(KEY_DRIFT_SPEED, 1.0f),
            colorPreset = colorPreset,
            targetFps = prefs.getInt(KEY_TARGET_FPS, 60),
            batterySaverAutoThrottle = prefs.getBoolean(KEY_BATTERY_SAVER_AUTO_THROTTLE, true),
            dampingSmoothness = prefs.getFloat(KEY_DAMPING_SMOOTHNESS, 0.14f)
        )
    }

    fun saveConfig(config: WallpaperConfig) {
        // Use commit() for source / path changes so the live wallpaper service
        // (which may start or reload immediately) always sees the latest values.
        val editor = prefs.edit()
            .putString(KEY_SOURCE_TYPE, config.sourceType.name)
            .putString(KEY_PRESET_ID, config.presetId)
            .putString(KEY_CUSTOM_IMAGE_PATH, config.customImagePath)
            .putFloat(KEY_DEPTH_INTENSITY, config.depthIntensity)
            .putFloat(KEY_PERSPECTIVE_TILT, config.perspectiveTilt)
            .putString(KEY_SENSOR_MODE, config.sensorMode.name)
            .putFloat(KEY_SENSOR_SENSITIVITY, config.sensorSensitivity)
            .putBoolean(KEY_INVERT_X, config.invertX)
            .putBoolean(KEY_INVERT_Y, config.invertY)
            .putBoolean(KEY_HOLOGRAPHIC_SHEEN, config.holographicSheen)
            .putFloat(KEY_SHEEN_INTENSITY, config.sheenIntensity)
            .putBoolean(KEY_PARTICLES_ENABLED, config.particlesEnabled)
            .putString(KEY_PARTICLE_TYPE, config.particleType.name)
            .putInt(KEY_PARTICLE_COUNT, config.particleCount)
            .putBoolean(KEY_AMBIENT_DRIFT, config.ambientDrift)
            .putFloat(KEY_DRIFT_SPEED, config.driftSpeed)
            .putString(KEY_COLOR_PRESET, config.colorPreset.name)
            .putInt(KEY_TARGET_FPS, config.targetFps)
            .putBoolean(KEY_BATTERY_SAVER_AUTO_THROTTLE, config.batterySaverAutoThrottle)
            .putFloat(KEY_DAMPING_SMOOTHNESS, config.dampingSmoothness)

        // commit() is synchronous and critical for wallpaper source changes
        editor.commit()
        _configFlow.value = config
    }

    suspend fun saveCustomPhoto(uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val destinationFile = File(context.filesDir, CUSTOM_WALLPAPER_FILENAME)

            // Delete previous custom image so we never keep a stale/corrupt file
            if (destinationFile.exists()) {
                destinationFile.delete()
            }

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(Exception("Cannot open image stream"))

            // Verify the file was written and is decodable
            if (!destinationFile.exists() || destinationFile.length() < 100) {
                return@withContext Result.failure(Exception("Saved image file is empty or missing"))
            }

            // Quick decode check so we fail early instead of falling back later
            val probe = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(destinationFile.absolutePath, probe)
            if (probe.outWidth <= 0 || probe.outHeight <= 0) {
                destinationFile.delete()
                return@withContext Result.failure(Exception("Unsupported or corrupt image format"))
            }

            val current = _configFlow.value
            val updated = current.copy(
                sourceType = WallpaperSourceType.CUSTOM_PHOTO,
                customImagePath = destinationFile.absolutePath
            )
            saveConfig(updated)
            Result.success(destinationFile.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun selectPreset(presetId: String) {
        val preset = BuiltInPresets.presets.find { it.id == presetId } ?: return
        val current = _configFlow.value
        val updated = current.copy(
            sourceType = WallpaperSourceType.PRESET,
            presetId = preset.id,
            depthIntensity = preset.defaultDepth,
            particleType = preset.defaultParticleType,
            colorPreset = preset.recommendedColorPreset
        )
        saveConfig(updated)
    }

    suspend fun loadWallpaperBitmap(
        config: WallpaperConfig,
        reqWidth: Int = 1080,
        reqHeight: Int = 2340
    ): Bitmap? = withContext(Dispatchers.IO) {
        try {
            when (config.sourceType) {
                WallpaperSourceType.CUSTOM_PHOTO -> {
                    val path = config.customImagePath
                    if (path != null && File(path).exists()) {
                        // Try primary decode first
                        var bmp = decodeSampledBitmapFromFile(path, reqWidth, reqHeight)
                        // Fallback: try again with more aggressive downsampling / ARGB if needed
                        if (bmp == null) {
                            bmp = decodeSampledBitmapFromFile(path, reqWidth / 2, reqHeight / 2)
                        }
                        if (bmp != null) {
                            return@withContext bmp
                        }
                    }
                    // Only fall back to preset if custom truly cannot be loaded
                    loadPresetBitmap("preset_cyber_nebula", reqWidth, reqHeight)
                }
                WallpaperSourceType.PRESET -> {
                    val preset = BuiltInPresets.presets.find { it.id == config.presetId }
                    val resName = preset?.drawableResName ?: "preset_cyber_nebula"
                    loadPresetBitmap(resName, reqWidth, reqHeight)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun loadPresetBitmap(resName: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        val resId = context.resources.getIdentifier(resName, "drawable", context.packageName)
        if (resId == 0) return null

        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeResource(context.resources, resId, options)

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
        options.inJustDecodeBounds = false
        options.inPreferredConfig = Bitmap.Config.RGB_565 // Memory and GPU efficient!

        return BitmapFactory.decodeResource(context.resources, resId, options)
    }

    private fun decodeSampledBitmapFromFile(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(path, options)

            if (options.outWidth <= 0 || options.outHeight <= 0) return null

            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            // Prefer RGB_565 for memory, but fall back to ARGB_8888 if decode fails
            options.inPreferredConfig = Bitmap.Config.RGB_565

            var bmp = BitmapFactory.decodeFile(path, options)
            if (bmp == null) {
                options.inPreferredConfig = Bitmap.Config.ARGB_8888
                options.inSampleSize = (options.inSampleSize * 2).coerceAtLeast(1)
                bmp = BitmapFactory.decodeFile(path, options)
            }
            bmp
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1

        if (height > reqHeight || width > reqWidth) {
            val halfHeight: Int = height / 2
            val halfWidth: Int = width / 2

            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    companion object {
        const val PREFS_NAME = "motion_wallpaper_prefs"
        const val CUSTOM_WALLPAPER_FILENAME = "custom_3d_wallpaper.jpg"

        private const val KEY_SOURCE_TYPE = "key_source_type"
        private const val KEY_PRESET_ID = "key_preset_id"
        private const val KEY_CUSTOM_IMAGE_PATH = "key_custom_image_path"
        private const val KEY_DEPTH_INTENSITY = "key_depth_intensity"
        private const val KEY_PERSPECTIVE_TILT = "key_perspective_tilt"
        private const val KEY_SENSOR_MODE = "key_sensor_mode"
        private const val KEY_SENSOR_SENSITIVITY = "key_sensor_sensitivity"
        private const val KEY_INVERT_X = "key_invert_x"
        private const val KEY_INVERT_Y = "key_invert_y"
        private const val KEY_HOLOGRAPHIC_SHEEN = "key_holographic_sheen"
        private const val KEY_SHEEN_INTENSITY = "key_sheen_intensity"
        private const val KEY_PARTICLES_ENABLED = "key_particles_enabled"
        private const val KEY_PARTICLE_TYPE = "key_particle_type"
        private const val KEY_PARTICLE_COUNT = "key_particle_count"
        private const val KEY_AMBIENT_DRIFT = "key_ambient_drift"
        private const val KEY_DRIFT_SPEED = "key_drift_speed"
        private const val KEY_COLOR_PRESET = "key_color_preset"
        private const val KEY_TARGET_FPS = "key_target_fps"
        private const val KEY_BATTERY_SAVER_AUTO_THROTTLE = "key_battery_saver_auto_throttle"
        private const val KEY_DAMPING_SMOOTHNESS = "key_damping_smoothness"

        @Volatile
        private var INSTANCE: WallpaperRepository? = null

        fun getInstance(context: Context): WallpaperRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: WallpaperRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
