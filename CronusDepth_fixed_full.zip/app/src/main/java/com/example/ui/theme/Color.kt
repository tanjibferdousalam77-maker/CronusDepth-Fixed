package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Galaxy S25 FE & One UI 9 Premium Dark Palette
val GalaxyOledDark = Color(0xFF080B10)
val GalaxySurfaceDark = Color(0xFF111622)
val GalaxyCardDark = Color(0xFF171E2E)
val GalaxyCardBorder = Color(0xFF263249)

val OneUiCyan = Color(0xFF00E5FF)
val OneUiBlue = Color(0xFF2979FF)
val OneUiPurple = Color(0xFF7C4DFF)
val OneUiPink = Color(0xFFFF2A85)
val OneUiAmber = Color(0xFFFFB300)
val OneUiGreen = Color(0xFF00E676)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

val GlassOverlay = Color(0x331E293B)
val GlassBorder = Color(0x40FFFFFF)
