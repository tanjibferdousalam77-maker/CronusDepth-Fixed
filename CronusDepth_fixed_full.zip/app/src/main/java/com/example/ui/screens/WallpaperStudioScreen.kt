package com.example.ui.screens

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WallpaperRepository
import com.example.model.BuiltInPresets
import com.example.model.ColorPreset
import com.example.model.ParticleType
import com.example.model.SensorMode
import com.example.model.WallpaperConfig
import com.example.model.WallpaperSourceType
import com.example.ui.components.GalaxyOverlay
import com.example.ui.components.MotionCanvasView
import com.example.ui.components.PreviewOverlayMode
import com.example.ui.theme.GalaxyCardBorder
import com.example.ui.theme.GalaxyCardDark
import com.example.ui.theme.GalaxyOledDark
import com.example.ui.theme.GalaxySurfaceDark
import com.example.ui.theme.OneUiAmber
import com.example.ui.theme.OneUiCyan
import com.example.ui.theme.OneUiGreen
import com.example.ui.theme.OneUiPink
import com.example.ui.theme.OneUiPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.wallpaper.MotionWallpaperService
import kotlinx.coroutines.launch

@Composable
fun WallpaperStudioScreen(
    repository: WallpaperRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val config by repository.configFlow.collectAsState()

    var activeBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var measuredFps by remember { mutableIntStateOf(60) }
    var autoOrbitDemo by remember { mutableStateOf(false) }
    var overlayMode by remember { mutableStateOf(PreviewOverlayMode.ONE_UI_HOME) }
    var selectedTab by remember { mutableIntStateOf(0) }

    // Load active wallpaper bitmap whenever source changes
    LaunchedEffect(config.sourceType, config.presetId, config.customImagePath) {
        activeBitmap = repository.loadWallpaperBitmap(config, 1080, 2340)
    }

    // Photo picker launcher (Zero-permission modern picker)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val result = repository.saveCustomPhoto(uri)
                if (result.isSuccess) {
                    Toast.makeText(context, "Custom photo loaded in 3D engine!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Failed to load image: ${result.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(GalaxyOledDark)
            .statusBarsPadding()
    ) {
        // App Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(listOf(OneUiCyan, OneUiPurple))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Wallpaper,
                        contentDescription = "Logo",
                        tint = GalaxyOledDark,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "MotionWall 3D",
                        color = TextPrimaryDark,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = (-0.3).sp
                    )
                    Text(
                        text = "Galaxy S25 FE • One UI 9 Engine",
                        color = OneUiCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Pick Custom Photo Action Button
            Button(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GalaxyCardDark,
                    contentColor = OneUiCyan
                ),
                border = BorderStroke(1.dp, GalaxyCardBorder),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("pick_photo_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = "Pick photo",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Pick Photo", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Studio Content Scroll List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Section 1: Live Interactive 3D Preview Frame
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                        .aspectRatio(9f / 14f)
                        .clip(RoundedCornerShape(32.dp))
                        .border(1.5.dp, GalaxyCardBorder, RoundedCornerShape(32.dp))
                        .background(Color.Black)
                ) {
                    // Motion Canvas
                    MotionCanvasView(
                        config = config,
                        bitmap = activeBitmap,
                        autoOrbitDemo = autoOrbitDemo,
                        onFpsCalculated = { measuredFps = it },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Samsung One UI 9 / Lock Screen Mockup Overlays
                    GalaxyOverlay(
                        mode = overlayMode,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Top Floating Preview Stats & Controls
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // FPS / Engine Badge
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xCC080B10))
                                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (measuredFps >= 50) OneUiGreen else OneUiAmber)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$measuredFps FPS",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Auto Orbit Demo Button
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (autoOrbitDemo) OneUiCyan.copy(alpha = 0.9f) else Color(0xCC080B10))
                                .border(1.dp, if (autoOrbitDemo) OneUiCyan else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                                .clickable { autoOrbitDemo = !autoOrbitDemo }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("orbit_demo_toggle"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (autoOrbitDemo) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = "Auto Motion Orbit",
                                tint = if (autoOrbitDemo) GalaxyOledDark else OneUiCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (autoOrbitDemo) "Orbiting" else "Auto Orbit",
                                color = if (autoOrbitDemo) GalaxyOledDark else Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Bottom Floating Mode Switcher Chips
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xDD080B10))
                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        PreviewChip(
                            label = "Canvas",
                            selected = overlayMode == PreviewOverlayMode.CLEAN_CANVAS,
                            onClick = { overlayMode = PreviewOverlayMode.CLEAN_CANVAS }
                        )
                        PreviewChip(
                            label = "Home",
                            selected = overlayMode == PreviewOverlayMode.ONE_UI_HOME,
                            onClick = { overlayMode = PreviewOverlayMode.ONE_UI_HOME }
                        )
                        PreviewChip(
                            label = "Lock",
                            selected = overlayMode == PreviewOverlayMode.ONE_UI_LOCK,
                            onClick = { overlayMode = PreviewOverlayMode.ONE_UI_LOCK }
                        )
                    }
                }
            }

            // Section 2: Preset Wallpapers Gallery
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, start = 20.dp, end = 20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "3D Wallpaper Presets",
                            color = TextPrimaryDark,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (config.sourceType == WallpaperSourceType.CUSTOM_PHOTO) {
                            Text(
                                text = "Using Custom Photo",
                                color = OneUiPink,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(horizontal = 2.dp)
                    ) {
                        // Custom photo card if present
                        if (config.customImagePath != null) {
                            item {
                                PresetCard(
                                    title = "Custom Photo",
                                    subtitle = "Your Selected Picture",
                                    isSelected = config.sourceType == WallpaperSourceType.CUSTOM_PHOTO,
                                    onClick = {
                                        repository.saveConfig(
                                            config.copy(sourceType = WallpaperSourceType.CUSTOM_PHOTO)
                                        )
                                    }
                                )
                            }
                        }

                        items(BuiltInPresets.presets) { preset ->
                            PresetCard(
                                title = preset.name,
                                subtitle = preset.subtitle,
                                isSelected = config.sourceType == WallpaperSourceType.PRESET && config.presetId == preset.id,
                                onClick = {
                                    repository.selectPreset(preset.id)
                                }
                            )
                        }
                    }
                }
            }

            // Section 3: Customization Tabs (3D Engine, Visual FX, Battery & Performance)
            item {
                Spacer(modifier = Modifier.height(20.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = GalaxySurfaceDark,
                    contentColor = OneUiCyan,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = OneUiCyan,
                            height = 3.dp
                        )
                    },
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, GalaxyCardBorder, RoundedCornerShape(16.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Layers, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("3D Engine", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Effects", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Battery", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
            }

            // Tab Content
            item {
                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                    when (selectedTab) {
                        0 -> DepthControlsTab(config = config, onUpdate = { repository.saveConfig(it) })
                        1 -> VisualEffectsTab(config = config, onUpdate = { repository.saveConfig(it) })
                        2 -> BatteryEngineTab(config = config, onUpdate = { repository.saveConfig(it) })
                    }
                }
            }
        }

        // Section 4: Bottom Floating Action Bar with "Apply 3D Live Wallpaper"
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, GalaxyOledDark.copy(alpha = 0.95f), GalaxyOledDark)
                    )
                )
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Button(
                onClick = {
                    applyLiveWallpaper(context)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("apply_wallpaper_button"),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = OneUiCyan,
                    contentColor = GalaxyOledDark
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Wallpaper,
                        contentDescription = "Set Live Wallpaper",
                        modifier = Modifier.size(20.dp),
                        tint = GalaxyOledDark
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Set as 3D Live Wallpaper",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = GalaxyOledDark
                    )
                }
            }
        }
    }
}

private fun applyLiveWallpaper(context: Context) {
    try {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
            putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(context, MotionWallpaperService::class.java)
            )
        }
        context.startActivity(intent)
        Toast.makeText(context, "Select 'Set Wallpaper' to activate on Home Screen!", Toast.LENGTH_LONG).show()
    } catch (_: Exception) {
        try {
            val fallbackIntent = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)
            context.startActivity(fallbackIntent)
        } catch (_: Exception) {
            Toast.makeText(context, "Live wallpaper chooser opened", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
private fun PreviewChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) OneUiCyan else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(
            text = label,
            color = if (selected) GalaxyOledDark else Color.White.copy(alpha = 0.8f),
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun PresetCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor by animateColorAsState(if (isSelected) OneUiCyan else GalaxyCardBorder)

    Card(
        modifier = Modifier
            .width(180.dp)
            .clickable(onClick = onClick)
            .testTag("preset_${title.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) GalaxyCardDark else GalaxySurfaceDark
        ),
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = TextPrimaryDark,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(OneUiCyan),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = GalaxyOledDark,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                color = TextSecondaryDark,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DepthControlsTab(
    config: WallpaperConfig,
    onUpdate: (WallpaperConfig) -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GalaxySurfaceDark),
        border = BorderStroke(1.dp, GalaxyCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Parallax Depth Intensity Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Parallax Depth Intensity", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${String.format("%.1f", config.depthIntensity)}x", color = OneUiCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.depthIntensity,
                    onValueChange = { onUpdate(config.copy(depthIntensity = it)) },
                    valueRange = 1.0f..5.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = OneUiCyan,
                        activeTrackColor = OneUiCyan,
                        inactiveTrackColor = GalaxyCardBorder
                    )
                )
            }

            // 3D Perspective Tilt Angle
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "3D Camera Perspective Tilt", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${config.perspectiveTilt.toInt()}°", color = OneUiCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.perspectiveTilt,
                    onValueChange = { onUpdate(config.copy(perspectiveTilt = it)) },
                    valueRange = 5.0f..30.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = OneUiCyan,
                        activeTrackColor = OneUiCyan,
                        inactiveTrackColor = GalaxyCardBorder
                    )
                )
            }

            // Gyroscope Sensitivity
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Sensor Motion Sensitivity", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${String.format("%.1f", config.sensorSensitivity)}x", color = OneUiCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = config.sensorSensitivity,
                    onValueChange = { onUpdate(config.copy(sensorSensitivity = it)) },
                    valueRange = 0.5f..2.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = OneUiCyan,
                        activeTrackColor = OneUiCyan,
                        inactiveTrackColor = GalaxyCardBorder
                    )
                )
            }

            // Ambient Idle Breathing Motion Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Ambient Breathing Drift", color = TextPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "Subtle 3D motion while phone is resting on a desk",
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = config.ambientDrift,
                    onCheckedChange = { onUpdate(config.copy(ambientDrift = it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = GalaxyOledDark,
                        checkedTrackColor = OneUiCyan
                    )
                )
            }

            // Invert Tilt Axes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = config.invertX,
                        onCheckedChange = { onUpdate(config.copy(invertX = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = GalaxyOledDark, checkedTrackColor = OneUiCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Invert X", color = TextPrimaryDark, fontSize = 13.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = config.invertY,
                        onCheckedChange = { onUpdate(config.copy(invertY = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = GalaxyOledDark, checkedTrackColor = OneUiCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Invert Y", color = TextPrimaryDark, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun VisualEffectsTab(
    config: WallpaperConfig,
    onUpdate: (WallpaperConfig) -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GalaxySurfaceDark),
        border = BorderStroke(1.dp, GalaxyCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Holographic Sheen Toggle & Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Holographic Glass Sheen", color = TextPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "Dynamic iridescent glare reflecting tilt angles", color = TextSecondaryDark, fontSize = 11.sp)
                    }
                    Switch(
                        checked = config.holographicSheen,
                        onCheckedChange = { onUpdate(config.copy(holographicSheen = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = GalaxyOledDark, checkedTrackColor = OneUiPink)
                    )
                }
                if (config.holographicSheen) {
                    Slider(
                        value = config.sheenIntensity,
                        onValueChange = { onUpdate(config.copy(sheenIntensity = it)) },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = OneUiPink,
                            activeTrackColor = OneUiPink,
                            inactiveTrackColor = GalaxyCardBorder
                        )
                    )
                }
            }

            // 3D Particles Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "3D Floating Particle Layer", color = TextPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "Depth-reactive particles floating in foreground", color = TextSecondaryDark, fontSize = 11.sp)
                }
                Switch(
                    checked = config.particlesEnabled,
                    onCheckedChange = { onUpdate(config.copy(particlesEnabled = it)) },
                    colors = SwitchDefaults.colors(checkedThumbColor = GalaxyOledDark, checkedTrackColor = OneUiPurple)
                )
            }

            if (config.particlesEnabled) {
                Text(text = "Particle Style", color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ParticleStyleChip("Stardust", config.particleType == ParticleType.STARDUST) {
                        onUpdate(config.copy(particleType = ParticleType.STARDUST))
                    }
                    ParticleStyleChip("Fireflies", config.particleType == ParticleType.FIREFLIES) {
                        onUpdate(config.copy(particleType = ParticleType.FIREFLIES))
                    }
                    ParticleStyleChip("Neon", config.particleType == ParticleType.NEON_CYBER) {
                        onUpdate(config.copy(particleType = ParticleType.NEON_CYBER))
                    }
                    ParticleStyleChip("Snow", config.particleType == ParticleType.SNOW_CRYSTAL) {
                        onUpdate(config.copy(particleType = ParticleType.SNOW_CRYSTAL))
                    }
                }
            }

            // Color Tuning Preset
            Column {
                Text(text = "OLED Color Enhancement", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ColorPresetChip("Original", config.colorPreset == ColorPreset.ORIGINAL) {
                        onUpdate(config.copy(colorPreset = ColorPreset.ORIGINAL))
                    }
                    ColorPresetChip("AMOLED Boost", config.colorPreset == ColorPreset.VIBRANT_AMOLED) {
                        onUpdate(config.copy(colorPreset = ColorPreset.VIBRANT_AMOLED))
                    }
                    ColorPresetChip("Cyber Neon", config.colorPreset == ColorPreset.CYBER_NEON) {
                        onUpdate(config.copy(colorPreset = ColorPreset.CYBER_NEON))
                    }
                    ColorPresetChip("Deep OLED", config.colorPreset == ColorPreset.DEEP_CONTRAST) {
                        onUpdate(config.copy(colorPreset = ColorPreset.DEEP_CONTRAST))
                    }
                }
            }
        }
    }
}

@Composable
private fun BatteryEngineTab(
    config: WallpaperConfig,
    onUpdate: (WallpaperConfig) -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GalaxySurfaceDark),
        border = BorderStroke(1.dp, GalaxyCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Target FPS Selector
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Target Engine Refresh Rate", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "${config.targetFps} FPS", color = OneUiGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FpsChip(30, "30 FPS\nEco", config.targetFps == 30) { onUpdate(config.copy(targetFps = 30)) }
                    FpsChip(60, "60 FPS\nFluid", config.targetFps == 60) { onUpdate(config.copy(targetFps = 60)) }
                    FpsChip(90, "90 FPS\nDynamic", config.targetFps == 90) { onUpdate(config.copy(targetFps = 90)) }
                    FpsChip(120, "120 FPS\nS25 Ultra", config.targetFps == 120) { onUpdate(config.copy(targetFps = 120)) }
                }
            }

            // Battery Saver Auto Throttle Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Auto Battery Saver Throttle", color = TextPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "Automatically drops to 30 FPS when Android battery saver is active",
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = config.batterySaverAutoThrottle,
                    onCheckedChange = { onUpdate(config.copy(batterySaverAutoThrottle = it)) },
                    colors = SwitchDefaults.colors(checkedThumbColor = GalaxyOledDark, checkedTrackColor = OneUiGreen)
                )
            }

            // Sensor Engine Mode
            Column {
                Text(text = "Motion Sensor Pipeline", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SensorModeCard(
                        title = "6-Axis Fused Gyro",
                        subtitle = "Silky smooth rotation",
                        selected = config.sensorMode == SensorMode.FUSION_GYRO,
                        onClick = { onUpdate(config.copy(sensorMode = SensorMode.FUSION_GYRO)) },
                        modifier = Modifier.weight(1f)
                    )
                    SensorModeCard(
                        title = "3-Axis Eco Accel",
                        subtitle = "Ultra low power",
                        selected = config.sensorMode == SensorMode.ACCELEROMETER_ECO,
                        onClick = { onUpdate(config.copy(sensorMode = SensorMode.ACCELEROMETER_ECO)) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Power Efficiency Summary Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0x2200E676))
                    .border(1.dp, Color(0x4400E676), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = OneUiGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Battery Optimization Active",
                            color = OneUiGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "• 0% CPU/GPU when screen is off or in other apps\n• Sleep rendering on stillness (pauses when motionless)\n• Hardware-accelerated surface rendering",
                        color = TextPrimaryDark.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ParticleStyleChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) OneUiPurple else GalaxyCardDark)
            .border(1.dp, if (selected) OneUiPurple else GalaxyCardBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else TextSecondaryDark,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun ColorPresetChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) OneUiCyan else GalaxyCardDark)
            .border(1.dp, if (selected) OneUiCyan else GalaxyCardBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) GalaxyOledDark else TextSecondaryDark,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun FpsChip(
    fps: Int,
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) OneUiGreen else GalaxyCardDark)
            .border(1.dp, if (selected) OneUiGreen else GalaxyCardBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (selected) GalaxyOledDark else TextPrimaryDark,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            lineHeight = 14.sp
        )
    }
}

@Composable
private fun SensorModeCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) GalaxyCardDark else GalaxySurfaceDark)
            .border(1.dp, if (selected) OneUiCyan else GalaxyCardBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title,
                color = if (selected) OneUiCyan else TextPrimaryDark,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = TextSecondaryDark,
                fontSize = 10.sp
            )
        }
    }
}
