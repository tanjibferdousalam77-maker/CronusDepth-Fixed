package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = OneUiCyan,
    onPrimary = GalaxyOledDark,
    primaryContainer = GalaxyCardDark,
    onPrimaryContainer = OneUiCyan,
    secondary = OneUiPurple,
    onSecondary = TextPrimaryDark,
    secondaryContainer = GalaxyCardDark,
    onSecondaryContainer = OneUiPurple,
    tertiary = OneUiPink,
    background = GalaxyOledDark,
    onBackground = TextPrimaryDark,
    surface = GalaxySurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = GalaxyCardDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = GalaxyCardBorder
)

private val LightColorScheme = DarkColorScheme // Always prefer luxury dark mode for 3D wallpaper studio & battery saving

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent cyber/one-ui theme for wallpaper studio
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> DarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
