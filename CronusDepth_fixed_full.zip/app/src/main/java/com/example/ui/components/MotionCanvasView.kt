package com.example.ui.components

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.example.engine.MotionSensorTracker
import com.example.engine.Wallpaper3DRenderer
import com.example.model.WallpaperConfig
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MotionCanvasView(
    config: WallpaperConfig,
    bitmap: Bitmap?,
    autoOrbitDemo: Boolean,
    onFpsCalculated: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val renderer = remember { Wallpaper3DRenderer() }

    var currentTiltX by remember { mutableFloatStateOf(0f) }
    var currentTiltY by remember { mutableFloatStateOf(0f) }

    val sensorTracker = remember {
        MotionSensorTracker(context) { x, y ->
            currentTiltX = x
            currentTiltY = y
        }
    }

    DisposableEffect(config.sensorMode) {
        sensorTracker.startTracking(config)
        onDispose {
            sensorTracker.stopTracking()
        }
    }

    var frameCount by remember { mutableIntStateOf(0) }
    var lastFpsCalcTime by remember { mutableStateOf(SystemClock.uptimeMillis()) }
    var orbitAngle by remember { mutableFloatStateOf(0f) }

    // High performance frame ticker for smooth animation in Compose preview
    LaunchedEffect(config, autoOrbitDemo) {
        var lastNanos = 0L

        while (true) {
            withFrameNanos { frameTimeNanos ->
                val dt = if (lastNanos == 0L) {
                    0.016f
                } else {
                    ((frameTimeNanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                }
                lastNanos = frameTimeNanos

                if (autoOrbitDemo) {
                    orbitAngle += dt * 1.6f
                    val orbitX = sin(orbitAngle) * 0.75f
                    val orbitY = cos(orbitAngle * 0.85f) * 0.55f
                    sensorTracker.injectTouchDelta((orbitX - currentTiltX) * 0.15f, (orbitY - currentTiltY) * 0.15f)
                }

                sensorTracker.updateFrame(dt, config)

                // Track FPS
                frameCount++
                val now = SystemClock.uptimeMillis()
                if (now - lastFpsCalcTime >= 1000L) {
                    val measuredFps = ((frameCount * 1000f) / (now - lastFpsCalcTime)).toInt()
                    onFpsCalculated(measuredFps)
                    frameCount = 0
                    lastFpsCalcTime = now
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val sensitivity = 0.003f
                        sensorTracker.injectTouchDelta(
                            -dragAmount.x * sensitivity,
                            dragAmount.y * sensitivity
                        )
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawIntoCanvas { composeCanvas ->
                val nativeCanvas = composeCanvas.nativeCanvas
                val width = size.width
                val height = size.height

                renderer.draw(
                    canvas = nativeCanvas,
                    bitmap = bitmap,
                    width = width,
                    height = height,
                    tiltX = currentTiltX,
                    tiltY = currentTiltY,
                    config = config,
                    deltaTimeSeconds = 0.016f,
                    isPowerSaverActive = false
                )
            }
        }
    }
}
