package com.example.engine

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.PowerManager
import com.example.model.SensorMode
import com.example.model.WallpaperConfig
import kotlin.math.cos
import kotlin.math.sin

class MotionSensorTracker(
    context: Context,
    private val onMotionUpdated: (tiltX: Float, tiltY: Float) -> Unit
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    private var rotationVectorSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private var gravitySensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)
    private var accelerometerSensor: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    // Raw sensor targets normalized in [-1.0f, 1.0f]
    var rawTiltX = 0f
        private set
    var rawTiltY = 0f
        private set

    // Smoothed values with exponential damping
    var smoothTiltX = 0f
        private set
    var smoothTiltY = 0f
        private set

    // Touch manual drag offset
    var touchTiltX = 0f
    var touchTiltY = 0f

    // Ambient drift accumulator
    private var driftTime = 0f

    private var isTracking = false
    private var currentMode = SensorMode.FUSION_GYRO

    fun startTracking(config: WallpaperConfig) {
        if (isTracking) stopTracking()

        currentMode = config.sensorMode

        // Battery conservation: use SENSOR_DELAY_UI (approx 60,000us / 16ms to 20ms) instead of FASTEST
        val delay = if (isPowerSaveActive(config)) {
            SensorManager.SENSOR_DELAY_NORMAL // ~200,000us for battery saving
        } else {
            SensorManager.SENSOR_DELAY_GAME
        }

        when (currentMode) {
            SensorMode.FUSION_GYRO -> {
                val sensor = rotationVectorSensor ?: gravitySensor ?: accelerometerSensor
                sensor?.let { sensorManager.registerListener(this, it, delay) }
            }
            SensorMode.ACCELEROMETER_ECO -> {
                accelerometerSensor?.let { sensorManager.registerListener(this, it, delay) }
            }
        }

        isTracking = true
    }

    fun stopTracking() {
        if (!isTracking) return
        sensorManager.unregisterListener(this)
        isTracking = false
    }

    fun isPowerSaveActive(config: WallpaperConfig): Boolean {
        return config.batterySaverAutoThrottle && powerManager.isPowerSaveMode
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientationAngles)
                // pitch: orientationAngles[1] (vertical tilt), roll: orientationAngles[2] (horizontal tilt)
                val pitch = orientationAngles[1]
                val roll = orientationAngles[2]

                // Normal phone holding posture is approx 45 degrees pitch (~0.7 rad)
                val normalizedY = ((pitch - 0.7f) * 1.5f).coerceIn(-1.0f, 1.0f)
                val normalizedX = (roll * 1.5f).coerceIn(-1.0f, 1.0f)

                rawTiltX = normalizedX
                rawTiltY = normalizedY
            }
            Sensor.TYPE_GRAVITY, Sensor.TYPE_ACCELEROMETER -> {
                // event.values[0]: X axis, event.values[1]: Y axis
                val normX = (event.values[0] / 9.8f).coerceIn(-1.0f, 1.0f)
                val normY = ((event.values[1] - 5.0f) / 9.8f).coerceIn(-1.0f, 1.0f)

                rawTiltX = -normX
                rawTiltY = normY
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No-op
    }

    /**
     * Called on each frame step to update physics and interpolation.
     * @param deltaTimeSeconds Elapsed frame time
     * @param config Active wallpaper config
     */
    fun updateFrame(deltaTimeSeconds: Float, config: WallpaperConfig) {
        var targetX = rawTiltX * config.sensorSensitivity
        var targetY = rawTiltY * config.sensorSensitivity

        if (config.invertX) targetX = -targetX
        if (config.invertY) targetY = -targetY

        // Add touch drag bias
        targetX += touchTiltX
        targetY += touchTiltY

        // Add ambient breathing drift if enabled
        if (config.ambientDrift) {
            driftTime += deltaTimeSeconds * config.driftSpeed
            val driftX = sin(driftTime * 0.9f) * 0.12f
            val driftY = cos(driftTime * 0.7f) * 0.09f
            targetX += driftX
            targetY += driftY
        }

        // Clamp final targets
        targetX = targetX.coerceIn(-1.5f, 1.5f)
        targetY = targetY.coerceIn(-1.5f, 1.5f)

        // Exponential smoothing (damping) for ultra silky fluid movement.
        // Slightly stronger base damping reduces residual sensor jitter that looked like glitching.
        val factor = (config.dampingSmoothness * 0.85f).coerceIn(0.05f, 0.35f)
        smoothTiltX += (targetX - smoothTiltX) * factor
        smoothTiltY += (targetY - smoothTiltY) * factor

        // Gradually decay touch tilt back to zero (slightly faster for cleaner feel)
        touchTiltX *= 0.90f
        touchTiltY *= 0.90f

        onMotionUpdated(smoothTiltX, smoothTiltY)
    }

    fun injectTouchDelta(deltaX: Float, deltaY: Float) {
        touchTiltX = (touchTiltX + deltaX).coerceIn(-1.2f, 1.2f)
        touchTiltY = (touchTiltY + deltaY).coerceIn(-1.2f, 1.2f)
    }

    fun reset() {
        rawTiltX = 0f
        rawTiltY = 0f
        smoothTiltX = 0f
        smoothTiltY = 0f
        touchTiltX = 0f
        touchTiltY = 0f
        driftTime = 0f
    }
}
