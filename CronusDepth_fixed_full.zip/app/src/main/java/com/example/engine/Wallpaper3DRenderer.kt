package com.example.engine

import android.graphics.Bitmap
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.example.model.ColorPreset
import com.example.model.ParticleType
import com.example.model.WallpaperConfig
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

data class Particle3D(
    var x: Float,
    var y: Float,
    var z: Float,           // Depth factor: 0.1 (far background) to 1.0 (near camera)
    var baseRadius: Float,
    var alpha: Float,
    var speed: Float,
    var phase: Float,
    var color: Int
)

class Wallpaper3DRenderer {

    private val camera = Camera()
    private val matrix3D = Matrix()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val srcRect = Rect()
    private val dstRect = RectF()

    private val particles = ArrayList<Particle3D>()
    private var lastParticleType: ParticleType? = null
    private var lastParticleCount: Int = 0

    private var activeColorPreset: ColorPreset = ColorPreset.ORIGINAL

    init {
        sheenPaint.style = Paint.Style.FILL
    }

    private fun ensureParticles(config: WallpaperConfig, width: Float, height: Float) {
        if (particles.size != config.particleCount || lastParticleType != config.particleType) {
            particles.clear()
            lastParticleType = config.particleType
            lastParticleCount = config.particleCount

            val rnd = Random(42)
            for (i in 0 until config.particleCount) {
                val z = 0.2f + rnd.nextFloat() * 0.8f
                val color = when (config.particleType) {
                    ParticleType.STARDUST -> {
                        val hues = intArrayOf(
                            Color.WHITE,
                            Color.rgb(180, 240, 255),
                            Color.rgb(220, 200, 255)
                        )
                        hues[rnd.nextInt(hues.size)]
                    }
                    ParticleType.FIREFLIES -> {
                        val hues = intArrayOf(
                            Color.rgb(255, 215, 0),
                            Color.rgb(255, 170, 50),
                            Color.rgb(180, 255, 100)
                        )
                        hues[rnd.nextInt(hues.size)]
                    }
                    ParticleType.NEON_CYBER -> {
                        val hues = intArrayOf(
                            Color.rgb(0, 245, 255),
                            Color.rgb(255, 0, 128),
                            Color.rgb(120, 0, 255)
                        )
                        hues[rnd.nextInt(hues.size)]
                    }
                    ParticleType.SNOW_CRYSTAL -> {
                        Color.rgb(220, 240, 255)
                    }
                }

                particles.add(
                    Particle3D(
                        x = rnd.nextFloat() * width,
                        y = rnd.nextFloat() * height,
                        z = z,
                        baseRadius = (2.0f + rnd.nextFloat() * 5.0f) * z,
                        alpha = 0.3f + rnd.nextFloat() * 0.6f,
                        speed = (15.0f + rnd.nextFloat() * 25.0f) * z,
                        phase = rnd.nextFloat() * (2 * PI).toFloat(),
                        color = color
                    )
                )
            }
        }
    }

    fun updateColorFilter(preset: ColorPreset) {
        if (activeColorPreset == preset) return
        activeColorPreset = preset

        when (preset) {
            ColorPreset.ORIGINAL -> {
                bitmapPaint.colorFilter = null
            }
            ColorPreset.VIBRANT_AMOLED -> {
                // Boost saturation and contrast
                val cm = ColorMatrix()
                cm.setSaturation(1.35f)
                val contrast = 1.15f
                val t = (1.0f - contrast) / 2.0f * 255.0f
                val contrastMatrix = ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, t,
                        0f, contrast, 0f, 0f, t,
                        0f, 0f, contrast, 0f, t,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                cm.postConcat(contrastMatrix)
                bitmapPaint.colorFilter = ColorMatrixColorFilter(cm)
            }
            ColorPreset.CYBER_NEON -> {
                val cm = ColorMatrix(
                    floatArrayOf(
                        1.0f, 0f, 0.2f, 0f, 10f,
                        0f, 1.15f, 0.1f, 0f, 15f,
                        0.2f, 0.1f, 1.35f, 0f, 30f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                bitmapPaint.colorFilter = ColorMatrixColorFilter(cm)
            }
            ColorPreset.DEEP_CONTRAST -> {
                val cm = ColorMatrix()
                cm.setSaturation(1.1f)
                val contrast = 1.25f
                val t = (1.0f - contrast) / 2.0f * 255.0f
                val contrastMatrix = ColorMatrix(
                    floatArrayOf(
                        contrast, 0f, 0f, 0f, t - 10f,
                        0f, contrast, 0f, 0f, t - 10f,
                        0f, 0f, contrast, 0f, t - 10f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                cm.postConcat(contrastMatrix)
                bitmapPaint.colorFilter = ColorMatrixColorFilter(cm)
            }
            ColorPreset.WARM_GOLDEN -> {
                val cm = ColorMatrix(
                    floatArrayOf(
                        1.25f, 0.1f, 0.0f, 0f, 20f,
                        0.05f, 1.1f, 0.0f, 0f, 10f,
                        0.0f, 0.05f, 0.85f, 0f, -10f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                bitmapPaint.colorFilter = ColorMatrixColorFilter(cm)
            }
        }
    }

    /**
     * Renders the 3D motion scene onto the provided canvas.
     */
    fun draw(
        canvas: Canvas,
        bitmap: Bitmap?,
        width: Float,
        height: Float,
        tiltX: Float,
        tiltY: Float,
        config: WallpaperConfig,
        deltaTimeSeconds: Float,
        isPowerSaverActive: Boolean = false
    ) {
        if (width <= 0f || height <= 0f) return

        updateColorFilter(config.colorPreset)

        val centerX = width / 2.0f
        val centerY = height / 2.0f

        // Dynamic overscan: fixed 1.20 was too small for high depth + tilt → edge clipping / glitching
        val depthFactor = config.depthIntensity.coerceIn(0.5f, 5.0f)
        val tiltFactor = (config.perspectiveTilt / 30f).coerceIn(0.3f, 1.5f)
        val scale = (1.12f + depthFactor * 0.11f + tiltFactor * 0.18f).coerceIn(1.18f, 1.65f)

        // Slightly reduced shift multipliers for more natural parallax (less extreme sliding)
        val maxShiftX = width * 0.065f * depthFactor
        val maxShiftY = height * 0.065f * depthFactor

        val shiftX = tiltX * maxShiftX
        val shiftY = tiltY * maxShiftY

        canvas.save()

        // 3D Camera Perspective Rotation (clamped tighter to reduce distortion / popping)
        val rotX = (tiltY * config.perspectiveTilt * 0.85f).coerceIn(-24f, 24f)
        val rotY = (-tiltX * config.perspectiveTilt * 0.85f).coerceIn(-24f, 24f)

        camera.save()
        camera.rotateX(rotX)
        camera.rotateY(rotY)
        camera.getMatrix(matrix3D)
        camera.restore()

        matrix3D.preTranslate(-centerX, -centerY)
        matrix3D.postScale(scale, scale)
        matrix3D.postTranslate(centerX + shiftX, centerY + shiftY)

        canvas.concat(matrix3D)

        // Draw Background Bitmap or deep cosmic gradient fallback
        if (bitmap != null && !bitmap.isRecycled) {
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            dstRect.set(0f, 0f, width, height)
            canvas.drawBitmap(bitmap, srcRect, dstRect, bitmapPaint)
        } else {
            // High quality dark fallback canvas
            val fallbackPaint = Paint().apply {
                shader = RadialGradient(
                    centerX, centerY, width * 0.9f,
                    intArrayOf(Color.rgb(20, 30, 55), Color.rgb(8, 12, 20)),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, width, height, fallbackPaint)
        }

        canvas.restore()

        // Draw 3D Floating Particles if enabled and not in extreme power saver
        if (config.particlesEnabled && (!isPowerSaverActive || config.particleCount <= 15)) {
            ensureParticles(config, width, height)
            drawParticles(canvas, width, height, tiltX, tiltY, config, deltaTimeSeconds)
        }

        // Draw Holographic Sheen / Specular Light Glare
        if (config.holographicSheen && config.sheenIntensity > 0.05f) {
            drawHolographicSheen(canvas, width, height, tiltX, tiltY, config.sheenIntensity)
        }
    }

    private fun drawParticles(
        canvas: Canvas,
        width: Float,
        height: Float,
        tiltX: Float,
        tiltY: Float,
        config: WallpaperConfig,
        deltaTimeSeconds: Float
    ) {
        val dt = deltaTimeSeconds.coerceIn(0.001f, 0.05f)

        for (p in particles) {
            // Update particle position
            when (config.particleType) {
                ParticleType.FIREFLIES -> {
                    p.y -= p.speed * dt
                    p.x += sin(p.phase) * 12.0f * dt
                    p.phase += dt * 2.5f
                }
                ParticleType.SNOW_CRYSTAL -> {
                    p.y += p.speed * dt
                    p.x += (tiltX * 20.0f + sin(p.phase) * 8.0f) * dt
                    p.phase += dt * 1.5f
                }
                else -> {
                    // Stardust / Neon sparks float gently with slight drift
                    p.y -= p.speed * 0.6f * dt
                    p.x += sin(p.phase) * 15.0f * dt
                    p.phase += dt * 1.8f
                }
            }

            // Wrap around screen
            if (p.y < -20f) p.y = height + 10f
            if (p.y > height + 20f) p.y = -10f
            if (p.x < -20f) p.x = width + 10f
            if (p.x > width + 20f) p.x = -10f

            // Parallax offset proportional to depth Z
            val particleParallaxX = tiltX * 80.0f * p.z * config.depthIntensity
            val particleParallaxY = tiltY * 80.0f * p.z * config.depthIntensity

            val drawX = p.x + particleParallaxX
            val drawY = p.y + particleParallaxY

            // Twinkle pulse
            val pulse = 0.7f + 0.3f * sin(p.phase)
            val currentAlpha = (p.alpha * pulse * 255).toInt().coerceIn(0, 255)

            particlePaint.color = p.color
            particlePaint.alpha = currentAlpha

            canvas.drawCircle(drawX, drawY, p.baseRadius * pulse, particlePaint)
        }
    }

    private fun drawHolographicSheen(
        canvas: Canvas,
        width: Float,
        height: Float,
        tiltX: Float,
        tiltY: Float,
        intensity: Float
    ) {
        // Light angle sweeps across the screen based on tilt
        val sheenCenterX = width * (0.5f + tiltX * 0.45f)
        val sheenCenterY = height * (0.5f + tiltY * 0.45f)

        val sheenWidth = width * 0.8f
        val maxAlpha = (intensity * 75).toInt().coerceIn(0, 120)

        val gradient = LinearGradient(
            sheenCenterX - sheenWidth, sheenCenterY - sheenWidth,
            sheenCenterX + sheenWidth, sheenCenterY + sheenWidth,
            intArrayOf(
                Color.argb(0, 255, 255, 255),
                Color.argb(maxAlpha / 2, 0, 245, 255),    // Holographic cyan
                Color.argb(maxAlpha, 255, 255, 255),      // Bright specular glint
                Color.argb(maxAlpha / 2, 255, 0, 180),    // Holographic magenta
                Color.argb(0, 255, 255, 255)
            ),
            floatArrayOf(0.0f, 0.40f, 0.50f, 0.60f, 1.0f),
            Shader.TileMode.CLAMP
        )

        sheenPaint.shader = gradient
        canvas.drawRect(0f, 0f, width, height, sheenPaint)
    }
}
