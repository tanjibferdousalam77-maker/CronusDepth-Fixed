package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.WallpaperRepository
import com.example.model.WallpaperConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("MotionWall 3D", appName)
    }

    @Test
    fun `wallpaper repository save and load config`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = WallpaperRepository.getInstance(context)
        val initialConfig = repo.loadConfig()
        assertNotNull(initialConfig)

        val updated = initialConfig.copy(
            depthIntensity = 3.5f,
            perspectiveTilt = 22.0f,
            targetFps = 120
        )
        repo.saveConfig(updated)

        val loaded = repo.loadConfig()
        assertEquals(3.5f, loaded.depthIntensity, 0.01f)
        assertEquals(22.0f, loaded.perspectiveTilt, 0.01f)
        assertEquals(120, loaded.targetFps)
    }
}
